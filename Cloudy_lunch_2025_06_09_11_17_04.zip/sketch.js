function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let trees = []; // Array para armazenar as árvores
let timer = 20; // Tempo total em segundos
let isGameActive = false; // Controle do estado do jogo
let treeCount = 0; // Contador de árvores plantadas
let victoryMessage = ""; // Mensagem de vitória
let targetTrees = 50; // Número de árvores a serem plantadas

function setup() {
  createCanvas(400, 400);
  textSize(32);
  startGame(); // Inicia o jogo ao carregar
}

function draw() {
  background(135, 206, 235); // Céu

  // Desenhar o sol
  fill(255, 204, 0); // Amarelo
  ellipse(50, 50, 80, 80); // Sol

  // Desenhar a grama
  fill(34, 139, 34); // Verde
  rect(0, 300, width, height - 300); // Grama

  // Desenhar montanhas
  fill(139, 69, 19); // Marrom
  triangle(100, 300, 150, 150, 200, 300); // Montanha 1
  triangle(250, 300, 300, 100, 350, 300); // Montanha 2

  // Desenhar todas as árvores
  for (let i = 0; i < trees.length; i++) {
    drawTree(trees[i].x, trees[i].y);
  }

  // Mostrar o tempo restante e o número de árvores plantadas
  fill(0);
  text(`Tempo: ${timer}`, 10, 30);
  text(`Árvores: ${treeCount}/${targetTrees}`, 10, 70);

  // Atualizar o cronômetro
  if (isGameActive) {
    if (frameCount % 60 === 0 && timer > 0) { // Atualiza a cada segundo
      timer--;
    }
    if (timer === 0) {
      isGameActive = false; // Para o jogo quando o tempo acabar
      alert(`Tempo esgotado! Você plantou ${treeCount} árvores.`);
    }
    if (treeCount >= targetTrees) {
      isGameActive = false; // Para o jogo se o número alvo de árvores for plantado
      victoryMessage = "Parabéns, você venceu!"; // Mensagem de vitória
      setTimeout(nextLevel, 2000); // Chama a próxima fase após 2 segundos
    }
  }

  // Exibir mensagem de vitória se o jogo não estiver ativo
  if (!isGameActive && victoryMessage) {
    fill(0);
    text(victoryMessage, 50, height / 2); // Exibe a mensagem no centro da tela
  }
}

// Função para desenhar uma árvore
function drawTree(x, y) {
  fill(139, 69, 19); // Tronco
  rect(x, y, 20, 50); // Tronco da árvore
  fill(0, 128, 0); // Folhas
  ellipse(x + 10, y - 20, 50, 50); // Folhas da árvore
}

// Função chamada quando o mouse é pressionado
function mousePressed() {
  if (isGameActive && treeCount < targetTrees) {
    // Adiciona uma nova árvore na posição do clique
    trees.push({ x: mouseX - 10, y: mouseY }); // Ajusta a posição para centralizar a árvore
    treeCount++; // Incrementa o contador de árvores plantadas
  }
}

// Função para iniciar o jogo
function startGame() {
  trees = []; // Reseta as árvores
  timer = 20; // Reseta o tempo para 20 segundos
  treeCount = 0; // Reseta o contador de árvores
  isGameActive = true; // Ativa o jogo
  victoryMessage = ""; // Reseta a mensagem de vitória
  targetTrees = 50; // Reseta o número alvo de árvores
}

// Função para avançar para a próxima fase
function nextLevel() {
  // Diminui o tempo e aumenta o número de árvores
  timer = 15; // Reduz o tempo para 15 segundos
  targetTrees = 60; // Aumenta o número de árvores para 60
  startGame(); // Reinicia o jogo com as novas configurações
}